# NCMS

Robust PHP MySQL Laravel CMS.

_By Martin (xthukuh@gmail.com)_


```
composer install --no-dev -o
php artisan migrate fresh --seed
php artisan storage:link

```

Link storage ```/x-link```
phpinfo ```/x-info```