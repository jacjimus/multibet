<?php $attributes = $attributes->exceptProps(['menu', 'guestMenu', 'authMenu']); ?>
<?php foreach (array_filter((['menu', 'guestMenu', 'authMenu']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!-- navbar -->
<nav <?php echo e($attributes->merge(['id' => 'navbar', 'class' => 'navbar navbar-expand-lg navbar-dark fixed-top' ])); ?>>
	<div class="container">

		<!-- brand -->
		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.link','data' => ['class' => 'navbar-brand','scrollTo' => '#top','href' => ''.e(url('/') == url()->current() ? 'javascript:' : '/').'']]); ?>
<?php $component->withName('controls.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'navbar-brand','scroll-to' => '#top','href' => ''.e(url('/') == url()->current() ? 'javascript:' : '/').'']); ?>
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.img','data' => ['src' => asset(config('app.logo')),'alt' => config('app.name')]]); ?>
<?php $component->withName('controls.img'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset(config('app.logo'))),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(config('app.name'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

		<!-- toggler -->
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#menu" aria-expanded="false">
			<?php echo app('translator')->get('Menu'); ?>
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['icon' => 'bars','class' => 'ml-1']]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'bars','class' => 'ml-1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		</button>

		<!-- collapse -->
		<div class="collapse navbar-collapse" id="menu">
			<ul class="navbar-nav ml-auto">

				<!-- menu -->
				<?php echo e($menu ?? ''); ?>


				<?php if(auth()->guard()->guest()): ?>
				<!-- guest -->
				<?php echo e($guestMenu ?? ''); ?>




				<!-- guest - login -->
				<li class="nav-item">
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.link','data' => ['class' => 'nav-link','href' => url('login'),'text' => trans('auth.login-nav')]]); ?>
<?php $component->withName('controls.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'nav-link','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(url('login')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(trans('auth.login-nav'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
				</li>
				<!-- /guest -->
				<?php endif; ?>

				<?php if(auth()->guard()->check()): ?>
				<!-- auth -->
				<?php echo e($authMenu ?? ''); ?>


				

				<!-- auth - user -->
				<li class="nav-item dropdown navbar-user">

					<!-- user - avatar -->
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.link','data' => ['class' => 'nav-link dropdown-toggle p-0','href' => '#','role' => 'button','dataToggle' => 'dropdown','ariaHaspopup' => 'true','dataUser' => ''.e($app_user->id).'']]); ?>
<?php $component->withName('controls.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'nav-link dropdown-toggle p-0','href' => '#','role' => 'button','data-toggle' => 'dropdown','aria-haspopup' => 'true','data-user' => ''.e($app_user->id).'']); ?>
						<span class="mr-2 d-none d-lg-inline"><?php echo e($app_user->name); ?></span>
						<?php if($tmp = x_tstr($app_user->getAvatar())): ?>
						<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.img','data' => ['class' => 'avatar','src' => $tmp,'alt' => $app_user->name]]); ?>
<?php $component->withName('controls.img'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'avatar','src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tmp),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($app_user->name)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
						<?php else: ?>
						<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.img','data' => ['class' => 'avatar','src' => asset('assets/images/avatar-placeholder.png'),'alt' => $app_user->name]]); ?>
<?php $component->withName('controls.img'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'avatar','src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset('assets/images/avatar-placeholder.png')),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($app_user->name)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
						<?php endif; ?>
						<span class="ml-2 d-inline d-lg-none"><?php echo e($app_user->name); ?></span>
					 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

					<!-- user - menu -->
					<ul class="dropdown-menu">
						<!-- premium -->

						<li class="dropdown-divider"></li>

						
						<!-- logout -->
						<li>
							<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.link','data' => ['class' => 'dropdown-item','dataLogout' => true,'href' => url('logout')]]); ?>
<?php $component->withName('controls.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'dropdown-item','data-logout' => true,'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(url('logout'))]); ?>
								<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['icon' => 'lock']]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'lock']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
								<?php echo app('translator')->get('Logout'); ?>
							 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
						</li>
					</ul>
				</li>
				<!-- /auth -->
				<?php endif; ?>
			</ul>
		</div>
		<!-- /collapse -->
	</div>
</nav>
<!-- /navbar -->


<?php if(stripos($__env->yieldContent('page-head'), ($tmp = 'assets/css/components/page/navbar.css')) === false): ?>
<?php $__env->startSection('page-head'); ?>
	##parent-placeholder-8c2a1dec97189fb8b47bc4c6bbb02def3968aa3a##
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.css','data' => ['href' => asset($tmp)]]); ?>
<?php $component->withName('controls.css'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset($tmp))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>


<?php if(stripos($__env->yieldContent('page-scripts'), ($tmp = 'assets/js/components/page/navbar.js')) === false): ?>
<?php $__env->startSection('page-scripts'); ?>
	##parent-placeholder-79ddd4078f59048d36667733ca6691b0bc0f1e0a##
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.js','data' => ['src' => asset($tmp)]]); ?>
<?php $component->withName('controls.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset($tmp))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/page/navbar.blade.php ENDPATH**/ ?>