<?php if(isset($src)): ?>
<script <?php echo e($attributes->merge(['type' => 'text/javascript', 'src' => $src])); ?>></script>
<?php else: ?>
<script type="text/javascript">
	<?php echo e($slot); ?>

</script>
<?php endif; ?>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/controls/js.blade.php ENDPATH**/ ?>