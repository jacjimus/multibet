<!-- date-links -->
<div class="date-links table-wrapper shadow mt-3">
	<table>
		<tr>
			<!-- datepicker -->
			<td class="text-nowrap text-center">
				<?php echo $__env->make('fstats.welcome.datepicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</td>

			<!-- date links -->
			<?php if(!empty($fs_date_links)): ?>
			<?php $__currentLoopData = $fs_date_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<td class="text-nowrap text-center">
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.link','data' => ['class' => $item['active'] ? 'active' : '','href' => 'javascript:','fsMatches' => $item['date'],'title' => ''.e($item['day_date']).'','dataTime' => ''.e($item['time']).'','text' => $item['text']]]); ?>
<?php $component->withName('controls.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['active'] ? 'active' : ''),'href' => 'javascript:','fs-matches' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['date']),'title' => ''.e($item['day_date']).'','data-time' => ''.e($item['time']).'','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['text'])]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
			</td>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</tr>
	</table>
</div>
<!-- /date-links -->


<?php $__env->startSection('page-head'); ?>
	##parent-placeholder-8c2a1dec97189fb8b47bc4c6bbb02def3968aa3a##
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.css','data' => ['href' => asset('assets/css/fstats/date-links.css')]]); ?>
<?php $component->withName('controls.css'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset('assets/css/fstats/date-links.css'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/fstats/welcome/date-links.blade.php ENDPATH**/ ?>