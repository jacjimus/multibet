<?php $attributes = $attributes->exceptProps(['wrapperClass', 'labelClass', 'id', 'name', 'text', 'invalid', 'disabled', 'readonly']); ?>
<?php foreach (array_filter((['wrapperClass', 'labelClass', 'id', 'name', 'text', 'invalid', 'disabled', 'readonly']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$id = x_isset_b($id) ? trim($id) : 'inputs-checkbox-' . (x_isset_b($name) ? trim($name) : rand(1000, 9999));
$input_class = 'custom-control-input pointer';
if (x_isset_b($invalid)) $input_class .= ' is-invalid';
$attrs = ['class' => $input_class, 'type' => 'checkbox'];
if (x_isset_b($name)) $attrs['name'] = $name;
if (x_isset_b($disabled) || x_isset_b($readonly)) $attrs['disabled'] = true;
$input_attrs = $attributes->merge($attrs);
?>

<div class="inputs-checkbox custom-control custom-checkbox d-flex flex-nowrap <?php echo e($wrapperClass ?? ''); ?>">
	<input id="<?php echo e($id); ?>" <?php echo e($input_attrs); ?>>
	<label for="<?php echo e($id); ?>" class="custom-control-label pointer <?php echo e($labelClass ?? ''); ?>">
		<?php if(x_isset_b($text)): ?>
		<?php echo $text; ?>

		<?php elseif(x_isset_b($slot)): ?>
		<?php echo e($slot); ?>

		<?php endif; ?>
	</label>
</div>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/inputs/checkbox.blade.php ENDPATH**/ ?>