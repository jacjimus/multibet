<!-- matches-table -->
<div class="matches-table shadow mt-3 min-h300 bg-dark">
	<?php if(!is_null($fs_fetch)): ?>
	<div id="fs-fetch-status" class="bg-primary text-center text-dark small p-1">
		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['class' => 'fa-spin','icon' => 'spinner']]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'fa-spin','icon' => 'spinner']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		<span class="ml-2">
			<?php if($fs_fetch[0] == 1): ?>
			<?php echo app('translator')->get('Algorithm is fetching records... (This might take up to 20 seconds)'); ?>
			<?php else: ?>
			<?php echo app('translator')->get('Analysing records...'); ?>
			<?php endif; ?>
		</span>
	</div>
	<?php endif; ?>
	<div class="table-wrapper">
		

        <table id="fs-matches-table" data-date="<?php echo e($fs_show_date); ?>"></table>
        <br />
	</div>
	<div id="fs-matches-table-alert"></div>
</div>
<?php $__env->startSection('page-scripts'); ?>
    <script>
        $(function () {
            createAdvancedFilteringGrid();
        });

        function createAdvancedFilteringGrid() {
            $("#fs-matches-table").igGrid({
                autoGenerateColumns: false,
                columns: [
                    { headerText: "Match ID", key: "id", dataType: "string", hidden: true },
                    { headerText: "Date/Time", key: "time_text", dataType: "date", width: "10%" },
                    { headerText: "League", key: "league_name", dataType: "string",  width: "15%" },
                    { headerText: "Home team", key: "home_name", dataType: "string", width: "15%" },
                    { headerText: "Form", key: "home_form_last5", dataType: "number", width: "10%" },
                    { headerText: "Away team", key: "away_name", dataType: "string", width: "15%" },
                    { headerText: "Form", key: "away_form_last5", dataType: "number", width: "10%" },
                    { headerText: "Form diff.", key: "form_diff_last5", dataType: "number", width: "10%" },
                    { headerText: "Odds", key: "odds_max", dataType: "number", width: "10%" }
                ],
                dataSource: <?php echo json_encode($fs_match_list); ?>,
                renderCheckboxes: true,
                responseDataKey: "results",
                features: [
                    {
                        name: "Filtering",
                        type: "local",
                        mode: "advanced",
                        filterDialogContainment: "window"
                    },
                    {
                        name: "Paging",
                        type: "local",
                        pageSize: 30
                    }
                ]
            });
        }
    </script>

    <?php $__env->stopSection(); ?>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/fstats/welcome/matches-table.blade.php ENDPATH**/ ?>