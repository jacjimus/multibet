<?php if(isset($href)): ?>
<link <?php echo e($attributes->merge(['rel' => 'stylesheet', 'type' => 'text/css', 'href' => $href])); ?>>
<?php else: ?>
<style type="text/css">
	<?php echo e($slot); ?>

</style>
<?php endif; ?>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/controls/css.blade.php ENDPATH**/ ?>