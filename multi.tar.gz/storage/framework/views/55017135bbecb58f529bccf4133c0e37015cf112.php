<?php
$link_attrs = $attributes->merge([
	'class' => 'controls-link ' . (url($href) == url()->current() ? 'current active' : ''),
])
-> filter(function($value, $key){
	return !in_array($key, ['icon', 'text']);
});
?>
<a <?php echo e($link_attrs); ?>>
	<?php if(isset($icon)): ?><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['icon' => $icon]]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php endif; ?>
	<?php if(isset($text)): ?><?php echo $text; ?><?php endif; ?>
	<?php echo e($slot ?? ''); ?>

</a>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/controls/link.blade.php ENDPATH**/ ?>