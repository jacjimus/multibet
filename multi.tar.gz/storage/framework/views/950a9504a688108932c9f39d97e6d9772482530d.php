<?php $attributes = $attributes->exceptProps(['wrapperClass', 'iconLeft', 'btnClass', 'prepend', 'clear', 'append', 'iconRight', 'togglePassword', 'readonly', 'invalid']); ?>
<?php foreach (array_filter((['wrapperClass', 'iconLeft', 'btnClass', 'prepend', 'clear', 'append', 'iconRight', 'togglePassword', 'readonly', 'invalid']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$input_class = 'form-control flex-fill';
if ($clear = x_isset_b($clear)) $input_class .= ' input-clear';
if ($togglePassword = x_isset_b($togglePassword)) $input_class .= ' toggle-password';
if (x_isset_b($invalid)) $input_class .= ' is-invalid';
$attrs = ['class' => $input_class, 'type' => 'text'];
if (x_isset_b($readonly)) $attrs['readonly'] = true;
if (x_isset_b($disabled)) $attrs['disabled'] = true;
$input_attrs = $attributes->merge($attrs);
?>

<div class="inputs-input input-group d-flex flex-nowrap <?php echo e($wrapperClass ?? ''); ?>">
	<?php if(x_isset_b($iconLeft) || x_isset_b($prepend)): ?>
	<div class="input-group-prepend">
		<?php if(x_isset_b($iconLeft)): ?>
		<div class="input-group-text">
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['icon' => $iconLeft]]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconLeft)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		</div>
		<?php endif; ?>
		<?php if(x_isset_b($prepend)): ?>
		<?php echo $prepend; ?>
		<?php endif; ?>
	</div>
	<?php endif; ?>
	<input <?php echo e($input_attrs); ?> />
	<?php if(x_isset_b($iconRight) || x_isset_b($append) || $clear || $togglePassword): ?>
	<div class="input-group-append">
		<?php if($clear): ?>
		<button class="btn <?php echo e($btnClass ?? 'btn-outline-secondary'); ?> input-clear-btn d-none" type="button" title="<?php echo app('translator')->get('Clear'); ?>">
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['icon' => 'times']]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => 'times']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		</button>
		<?php endif; ?>
		<?php if($togglePassword): ?>
		<button class="btn <?php echo e($btnClass ?? 'btn-outline-secondary'); ?> toggle-password-btn d-none" type="button" title-hide="<?php echo app('translator')->get('Hide Password'); ?>" title-show="<?php echo app('translator')->get('Show Password'); ?>">
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['class' => 'password-hidden','icon' => 'eye-slash']]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'password-hidden','icon' => 'eye-slash']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['class' => 'password-showing d-none','icon' => 'eye']]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'password-showing d-none','icon' => 'eye']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		</button>
		<?php endif; ?>
		<?php if(x_isset_b($iconRight)): ?>
		<div class="input-group-text">
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['icon' => $iconRight]]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconRight)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		</div>
		<?php endif; ?>
		<?php if(x_isset_b($append)): ?>
		<?php echo $append ?>
		<?php endif; ?>
	</div>
	<?php endif; ?>
</div>


<?php if(stripos($__env->yieldContent('page-scripts'), $tmp = 'assets/js/components/inputs/input.js') === false): ?>
<?php $__env->startSection('page-scripts'); ?>
	##parent-placeholder-79ddd4078f59048d36667733ca6691b0bc0f1e0a##
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.js','data' => ['src' => asset($tmp)]]); ?>
<?php $component->withName('controls.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset($tmp))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/inputs/input.blade.php ENDPATH**/ ?>