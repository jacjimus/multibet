<?php

namespace App\Console;

use Illuminate\Console\Command;
use Exception;

class NcmsCommand extends Command
{
	//..
}
