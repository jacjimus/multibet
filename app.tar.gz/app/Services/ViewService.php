<?php

namespace App\Services;

use Exception;


class ViewService
{
	public function __construct(){
		//..
	}

	public function getMetaTags(){
		//..
	}
}