<img {{ $attributes->merge(['draggable' => isset($draggable) ? $draggable : 'false', 'class' => 'controls-img']) }} />
