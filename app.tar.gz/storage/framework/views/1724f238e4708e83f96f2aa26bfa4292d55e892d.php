<!-- banner -->
<style>
.x-banner {
    background-color: var(--dark);
    color: var(--white);
    height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.x-banner .carousel-item {
	height: 150px;
}
.x-banner .carousel-item img {
	display: block;
	height: 100%;
	width: 100%;
    object-fit: cover;
	object-position: bottom;
}
</style>

<!-- /banner -->
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/fstats/welcome/banner.blade.php ENDPATH**/ ?>