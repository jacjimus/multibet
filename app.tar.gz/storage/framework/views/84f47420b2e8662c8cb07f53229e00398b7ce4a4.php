<<?php echo e($tag ?? 'i'); ?> <?php echo e($attributes->merge(['class' => 'controls-fa icon ' . (!preg_match('/fa(s|b|r)/i', $icon = trim($icon)) ? (isset($type) ? $type : 'fas') . ' ' : '') . (stripos($icon, 'fa-') === false ? 'fa-' : '') . $icon ])->filter(function($value, $key){ return $key != 'icon'; })); ?>></<?php echo e($tag ?? 'i'); ?>>


<?php if(stripos($__env->yieldContent('page-head'), 'lib/use.fontawesome.all.js') === false): ?>
<?php $__env->startSection('page-head'); ?>
	##parent-placeholder-8c2a1dec97189fb8b47bc4c6bbb02def3968aa3a##
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.js','data' => ['src' => asset('assets/js/lib/use.fontawesome.all.js')]]); ?>
<?php $component->withName('controls.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset('assets/js/lib/use.fontawesome.all.js'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/controls/fa.blade.php ENDPATH**/ ?>