<!-- matches-table -->
<div class="matches-table shadow mt-3 min-h300 bg-dark">
	<?php if(!is_null($fs_fetch)): ?>
	<div id="fs-fetch-status" class="bg-primary text-center text-dark small p-1">
		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.fa','data' => ['class' => 'fa-spin','icon' => 'spinner']]); ?>
<?php $component->withName('controls.fa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'fa-spin','icon' => 'spinner']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		<span class="ml-2">
			<?php if($fs_fetch[0] == 1): ?>
			<?php echo app('translator')->get('Algorithm is fetching records... (This might take up to 20 seconds)'); ?>
			<?php else: ?>
			<?php echo app('translator')->get('Analysing records...'); ?>
			<?php endif; ?>
		</span>
	</div>
	<?php endif; ?>
	<div class="table-wrapper">
		<table id="fs-matches-table" data-date="<?php echo e($fs_show_date); ?>">
			<thead>
				<tr>
					<th class="text-nowrap text-center"><?php echo app('translator')->get('Date/Time'); ?></th>
					<th class="text-nowrap text-center"><?php echo app('translator')->get('Home team'); ?></th>
					<th class="text-nowrap text-center"><?php echo app('translator')->get('Form'); ?></th>
					<th class="text-nowrap text-center"><?php echo app('translator')->get('Away team'); ?></th>
					<th class="text-nowrap text-center"><?php echo app('translator')->get('Form'); ?></th>
					<th class="text-nowrap text-center"><?php echo app('translator')->get('Form diff.'); ?></th>
					<th class="text-nowrap text-center"><?php echo app('translator')->get('Odds'); ?></th>
				</tr>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th  class="text-nowrap text-right">
                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.input','data' => ['id' => 'form-diff','name' => 'form_diff','type' => 'text','maxlength' => 2,'size' => 2,'style' => 'text-align: right','value' => ''.e($form_diff).'']]); ?>
<?php $component->withName('inputs.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'form-diff','name' => 'form_diff','type' => 'text','maxlength' => 2,'size' => 2,'style' => 'text-align: right','value' => ''.e($form_diff).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </th>
                    <th class="text-nowrap text-center">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.input','data' => ['id' => 'odds','name' => 'odds','type' => 'text','maxlength' => 9,'size' => 9,'style' => 'text-align: right','value' => ''.e($odds).'']]); ?>
<?php $component->withName('inputs.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'odds','name' => 'odds','type' => 'text','maxlength' => 9,'size' => 9,'style' => 'text-align: right','value' => ''.e($odds).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                    </th>

                </tr>
			</thead>
			<tbody>
				<?php if(!empty($fs_match_list)): ?>
				<?php $__currentLoopData = $fs_match_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<!-- match -->
				<tr data-item="<?php echo json_encode($item, 15, 512) ?>" data-fs-date="<?php echo e($item['date']); ?>"  data-fs-time-text="<?php echo e($item['time_text']); ?>">

					<!-- date -->
					<td class="text-nowrap text-center"><?php echo e($item['time_text']); ?></td>

					<!-- fixture -->
                    <td class="text-left"><?php echo e($item['home_name']); ?></td>

                    <td class="text-nowrap text-center <?php echo e($item['home_form_last5']); ?>"><?php echo e($item['home_form_last5']); ?></td>


                    <td class="text-left"><?php echo e($item['away_name']); ?></td>
                    <td class="text-nowrap text-center <?php echo e($item['away_form_last5']); ?>"><?php echo e($item['away_form_last5']); ?></td>

					<!-- odds -->
					<td class="text-nowrap text-center "><?php echo e(abs($item['home_form_last5']  - $item['away_form_last5'])); ?></td>
                    <!-- odds -->
                    <td class="text-nowrap text-center odds-from-<?php echo e($item['odds_from']); ?>">
                        <?php echo e($item['odds_tips'][$item['win_tip']] ?? $item['odds_tips']); ?>

                    </td>


                </tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
	<div id="fs-matches-table-alert"></div>
</div>
<!-- /matches-table -->
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/fstats/welcome/matches-table.blade.php ENDPATH**/ ?>