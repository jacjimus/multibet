<?php $attributes = $attributes->exceptProps(['label', 'labelClass', 'slotClass']); ?>
<?php foreach (array_filter((['label', 'labelClass', 'slotClass']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => 'controls-form-group form-group' ])); ?>>
	<?php if(x_isset_b($label)): ?>
	<label<?php if (x_isset_b($labelClass)) echo ' class="' . $labelClass . '"'; ?>><?php echo e($label); ?></label>
	<?php endif; ?>
	<?php if(x_isset_b($slotClass)): ?>
	<div class="<?php echo e($slotClass); ?>">
		<?php echo e($slot ?? ''); ?>

	</div>
	<?php else: ?>
	<?php echo e($slot ?? ''); ?>

	<?php endif; ?>
</div>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/controls/form-group.blade.php ENDPATH**/ ?>