<?php $attributes = $attributes->exceptProps(['id', 'env']); ?>
<?php foreach (array_filter((['id', 'env']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$id = x_tstr(x_isset_b($id) ? $id : config('services.google.analytics_id'));
$env = x_isset_b($env) ? $env : 'production';
$show_analytics = config('app.env') == $env && $id != '';
?>

<!-- google analytics -->
<?php if($show_analytics): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($id); ?>"></script>
<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());
	gtag('config', '<?php echo e($id); ?>');
</script>
<?php endif; ?>
<!-- /google analytics -->
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/page/google-analytics.blade.php ENDPATH**/ ?>