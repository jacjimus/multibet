<!-- footer -->
<style>
footer#footer {
	background-color: var(--black);
	color: var(--white);
    text-align: center;
    font-size: 0.9rem;
    font-family: var(--font-family-montserrat);
    padding: 3rem 0 2rem;
}
footer#footer a {
	color: inherit;
}
</style>
<footer id="footer">
	<div class="container">
		<div class="row align-items-center">
			<!-- Copyright -->
			<div class="col-lg-4 text-lg-left">
				<?php if(isset($copyright) && strlen($copyright = trim($copyright))): ?>
				<?php echo $copyright; ?>
				<?php else: ?>
				<?php echo app('translator')->get('Copyright'); ?> &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?><br><?php echo app('translator')->get('All rights reserved.'); ?>
				<?php endif; ?>
			</div>

			</div>


			</div>
		</div>
	</div>
</footer>
<!-- /footer -->
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/page/footer.blade.php ENDPATH**/ ?>