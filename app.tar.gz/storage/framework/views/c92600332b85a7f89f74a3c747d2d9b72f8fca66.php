<!-- form -->
<form <?php echo e($attributes->merge(['class' => 'controls-form'])); ?>>
<?php echo e($slot); ?>

</form>
<!-- /form -->


<?php if(stripos($__env->yieldContent('page-scripts'), $tmp = 'assets/js/components/controls/form.js') === false): ?>
<?php $__env->startSection('page-scripts'); ?>
	##parent-placeholder-79ddd4078f59048d36667733ca6691b0bc0f1e0a##
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.controls.js','data' => ['src' => asset($tmp)]]); ?>
<?php $component->withName('controls.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset($tmp))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php /**PATH /opt/homebrew/var/www/form-diff/resources/views/components/controls/form.blade.php ENDPATH**/ ?>